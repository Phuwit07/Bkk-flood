import { pgTable, serial, text, real, integer, pgEnum, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const riskLevelEnum = pgEnum("risk_level", ["low", "medium", "high", "critical"]);

export const floodZonesTable = pgTable("flood_zones", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  district: text("district").notNull(),
  riskLevel: riskLevelEnum("risk_level").notNull(),
  centerLatitude: real("center_latitude").notNull(),
  centerLongitude: real("center_longitude").notNull(),
  areaKm2: real("area_km2").notNull(),
  population: integer("population"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertFloodZoneSchema = createInsertSchema(floodZonesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertFloodZone = z.infer<typeof insertFloodZoneSchema>;
export type FloodZone = typeof floodZonesTable.$inferSelect;
