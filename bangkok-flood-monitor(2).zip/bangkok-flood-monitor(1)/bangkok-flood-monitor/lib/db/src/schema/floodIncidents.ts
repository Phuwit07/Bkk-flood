import { pgTable, serial, text, real, integer, pgEnum, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { floodZonesTable } from "./floodZones";

export const severityEnum = pgEnum("severity", ["low", "medium", "high", "critical"]);
export const incidentStatusEnum = pgEnum("incident_status", ["active", "monitoring", "resolved"]);

export const floodIncidentsTable = pgTable("flood_incidents", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  severity: severityEnum("severity").notNull(),
  status: incidentStatusEnum("status").notNull().default("active"),
  waterLevel: real("water_level").notNull(),
  district: text("district").notNull(),
  zoneId: integer("zone_id").references(() => floodZonesTable.id),
  imageUrl: text("image_url"),
  reportedAt: timestamp("reported_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertFloodIncidentSchema = createInsertSchema(floodIncidentsTable).omit({ id: true, reportedAt: true, updatedAt: true });
export type InsertFloodIncident = z.infer<typeof insertFloodIncidentSchema>;
export type FloodIncident = typeof floodIncidentsTable.$inferSelect;
