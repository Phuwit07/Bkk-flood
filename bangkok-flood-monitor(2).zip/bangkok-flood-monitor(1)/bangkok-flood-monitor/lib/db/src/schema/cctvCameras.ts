import { pgTable, serial, text, real, pgEnum, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const cameraStatusEnum = pgEnum("camera_status", ["online", "offline", "maintenance"]);

export const cctvCamerasTable = pgTable("cctv_cameras", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameTh: text("name_th").notNull(),
  district: text("district").notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  status: cameraStatusEnum("status").notNull().default("online"),
  waterLevel: real("water_level").notNull().default(0),
  isFloodAlert: boolean("is_flood_alert").notNull().default(false),
  streamUrl: text("stream_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertCctvCameraSchema = createInsertSchema(cctvCamerasTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCctvCamera = z.infer<typeof insertCctvCameraSchema>;
export type CctvCamera = typeof cctvCamerasTable.$inferSelect;
