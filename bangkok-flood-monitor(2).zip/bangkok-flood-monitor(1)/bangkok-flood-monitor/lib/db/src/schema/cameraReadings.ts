import { pgTable, serial, real, integer, timestamp } from "drizzle-orm/pg-core";
import { cctvCamerasTable } from "./cctvCameras";

export const cameraReadingsTable = pgTable("camera_readings", {
  id: serial("id").primaryKey(),
  cameraId: integer("camera_id").notNull().references(() => cctvCamerasTable.id),
  waterLevel: real("water_level").notNull(),
  recordedAt: timestamp("recorded_at").notNull(),
});

export type CameraReading = typeof cameraReadingsTable.$inferSelect;
