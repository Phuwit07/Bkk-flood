import { useParams, Link } from "wouter";
import { useGetFloodIncident, useUpdateFloodIncident, getListFloodIncidentsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { SeverityBadge, StatusBadge } from "@/components/SeverityBadge";

export default function IncidentDetail() {
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  const queryClient = useQueryClient();

  const { data: incident, isLoading, error } = useGetFloodIncident(id, { query: { enabled: !!id } });
  const updateMutation = useUpdateFloodIncident();

  const handleStatusChange = (newStatus: "active" | "monitoring" | "resolved") => {
    updateMutation.mutate(
      { id, data: { status: newStatus } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListFloodIncidentsQueryKey() });
        },
      }
    );
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-16 bg-card border border-border rounded animate-pulse" />
        ))}
      </div>
    );
  }

  if (error || !incident) {
    return (
      <div className="p-6">
        <div className="text-center py-12 text-muted-foreground">Incident not found</div>
        <div className="text-center mt-4">
          <Link href="/incidents"><a className="text-primary hover:underline text-sm">Back to incidents</a></Link>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-3xl">
      <div className="mb-6">
        <Link href="/incidents">
          <a className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-3 h-3">
              <path d="M15 18l-6-6 6-6" />
            </svg>
            Back to Incidents
          </a>
        </Link>
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-xl font-bold text-foreground">{incident.title}</h1>
            <p className="text-sm text-muted-foreground mt-0.5">{incident.district}</p>
          </div>
          <div className="flex items-center gap-2">
            <SeverityBadge severity={incident.severity} />
            <StatusBadge status={incident.status} />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground mb-1">Water Level</div>
          <div className="text-3xl font-bold font-mono text-blue-400">{incident.waterLevel} cm</div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground mb-1">Location</div>
          <div className="text-sm font-mono text-foreground">{incident.latitude.toFixed(4)}°N, {incident.longitude.toFixed(4)}°E</div>
          <div className="text-xs text-muted-foreground mt-1">{incident.district}</div>
        </div>
      </div>

      {incident.description && (
        <div className="bg-card border border-border rounded-lg p-4 mb-4">
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground mb-2">Description</div>
          <p className="text-sm text-foreground leading-relaxed">{incident.description}</p>
        </div>
      )}

      <div className="bg-card border border-border rounded-lg p-4 mb-4">
        <div className="text-[11px] uppercase tracking-widest text-muted-foreground mb-3">Timestamps</div>
        <div className="space-y-1.5 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Reported</span>
            <span className="font-mono text-foreground text-xs">{new Date(incident.reportedAt).toLocaleString("th-TH")}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Last Updated</span>
            <span className="font-mono text-foreground text-xs">{new Date(incident.updatedAt).toLocaleString("th-TH")}</span>
          </div>
        </div>
      </div>

      <div className="bg-card border border-border rounded-lg p-4">
        <div className="text-[11px] uppercase tracking-widest text-muted-foreground mb-3">Update Status</div>
        <div className="flex gap-2 flex-wrap">
          {(["active", "monitoring", "resolved"] as const).map((s) => (
            <button
              key={s}
              onClick={() => handleStatusChange(s)}
              disabled={incident.status === s || updateMutation.isPending}
              className={`px-4 py-2 rounded text-xs font-semibold uppercase tracking-wider transition-all disabled:opacity-50 ${
                incident.status === s
                  ? "bg-secondary text-foreground border border-primary"
                  : "bg-secondary text-muted-foreground border border-border hover:border-primary hover:text-foreground"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
        {updateMutation.isSuccess && (
          <p className="text-xs text-green-400 mt-2">Status updated successfully</p>
        )}
      </div>
    </div>
  );
}
