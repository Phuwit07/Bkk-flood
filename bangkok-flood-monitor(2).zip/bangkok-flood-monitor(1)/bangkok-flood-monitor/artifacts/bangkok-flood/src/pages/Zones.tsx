import { useListFloodZones } from "@workspace/api-client-react";
import { SeverityBadge } from "@/components/SeverityBadge";

export default function Zones() {
  const { data: zones, isLoading } = useListFloodZones();

  const riskOrder = { critical: 0, high: 1, medium: 2, low: 3 };
  const sorted = zones?.slice().sort((a, b) => (riskOrder[a.riskLevel as keyof typeof riskOrder] ?? 9) - (riskOrder[b.riskLevel as keyof typeof riskOrder] ?? 9)) ?? [];

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-xl font-bold text-foreground">Flood Risk Zones</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Monitored areas across Bangkok sorted by risk level</p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => <div key={i} className="h-48 bg-card border border-border rounded-lg animate-pulse" />)}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sorted.map((zone) => {
            const riskColors: Record<string, string> = {
              critical: "border-l-purple-500",
              high: "border-l-red-500",
              medium: "border-l-orange-500",
              low: "border-l-yellow-500",
            };
            return (
              <div key={zone.id} className={`bg-card border border-border border-l-4 ${riskColors[zone.riskLevel] ?? ""} rounded-lg p-4`}>
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="font-semibold text-foreground">{zone.name}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">{zone.district}</div>
                  </div>
                  <SeverityBadge severity={zone.riskLevel} />
                </div>

                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div>
                    <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Area</div>
                    <div className="text-sm font-mono text-foreground mt-0.5">{zone.areaKm2} km²</div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Population</div>
                    <div className="text-sm font-mono text-foreground mt-0.5">
                      {zone.population != null ? zone.population.toLocaleString() : "—"}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Active Incidents</div>
                    <div className={`text-sm font-mono font-bold mt-0.5 ${zone.activeIncidents > 0 ? "text-red-400" : "text-green-400"}`}>
                      {zone.activeIncidents}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Coordinates</div>
                    <div className="text-[11px] font-mono text-muted-foreground mt-0.5">
                      {zone.centerLatitude.toFixed(3)}°N
                    </div>
                  </div>
                </div>

                {zone.description && (
                  <p className="text-xs text-muted-foreground border-t border-border pt-2">{zone.description}</p>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
