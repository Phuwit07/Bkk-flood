import { useState } from "react";
import { useRealtimeFeed, type LiveCamera } from "@/hooks/useRealtimeFeed";
import CameraDetailPanel from "@/components/CameraDetailPanel";

type Filter = "all" | "online" | "alert" | "offline";

function WaterBar({ level, status }: { level: number; status: string }) {
  if (status === "offline") return <span className="text-xs text-muted-foreground font-mono">N/A</span>;
  const pct = Math.min((level / 100) * 100, 100);
  const color = level >= 60 ? "#ef4444" : level >= 35 ? "#f97316" : "#22c55e";
  return (
    <div className="flex items-center gap-2">
      <div className="w-24 h-1.5 bg-secondary rounded-full overflow-hidden flex-shrink-0">
        <div style={{ width: `${pct}%`, background: color }} className="h-full rounded-full transition-all duration-700" />
      </div>
      <span className="text-xs font-mono" style={{ color }}>{Math.round(level)} cm</span>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    online:      { label: "ออนไลน์",    cls: "bg-green-900/50 text-green-400 border border-green-800/50" },
    offline:     { label: "ออฟไลน์",    cls: "bg-gray-900/50 text-gray-400 border border-gray-700/50" },
    maintenance: { label: "ซ่อมบำรุง",  cls: "bg-purple-900/50 text-purple-400 border border-purple-800/50" },
  };
  const { label, cls } = map[status] ?? map.offline;
  return <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${cls}`}>{label}</span>;
}

function CameraIcon({ color, pulse }: { color: string; pulse?: boolean }) {
  return (
    <div className="relative flex-shrink-0" style={{ width: 28, height: 28 }}>
      {pulse && (
        <span className="absolute inset-0 rounded-full animate-ping opacity-30" style={{ background: color }} />
      )}
      <div className="w-7 h-7 rounded-full flex items-center justify-center border-2 border-white/20 relative z-10"
        style={{ background: color, boxShadow: `0 0 8px ${color}55` }}>
        <svg viewBox="0 0 24 24" fill="white" width="13" height="13">
          <path d="M9,3L7.17,5H4A2,2 0 0,0 2,7V19A2,2 0 0,0 4,21H20A2,2 0 0,0 22,19V7A2,2 0 0,0 20,5H16.83L15,3M12,8A5,5 0 0,1 17,13A5,5 0 0,1 12,18A5,5 0 0,1 7,13A5,5 0 0,1 12,8M12,10A3,3 0 0,0 9,13A3,3 0 0,0 12,16A3,3 0 0,0 15,13A3,3 0 0,0 12,10Z" />
        </svg>
      </div>
    </div>
  );
}

function markerColor(cam: LiveCamera) {
  if (cam.status === "offline") return "#6b7280";
  if (cam.status === "maintenance") return "#a855f7";
  if (cam.waterLevel >= 60) return "#ef4444";
  if (cam.waterLevel >= 35) return "#f97316";
  return "#22c55e";
}

export default function Cameras() {
  const { data: liveData, connected } = useRealtimeFeed();
  const [filter, setFilter] = useState<Filter>("all");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<LiveCamera | null>(null);

  const cameras = liveData?.cameras ?? [];

  const online = cameras.filter(c => c.status === "online").length;
  const alerts = cameras.filter(c => c.isFloodAlert && c.status === "online").length;
  const offline = cameras.filter(c => c.status === "offline" || c.status === "maintenance").length;

  const visible = cameras.filter(cam => {
    if (filter === "online" && cam.status !== "online") return false;
    if (filter === "alert" && !(cam.isFloodAlert && cam.status === "online")) return false;
    if (filter === "offline" && cam.status === "online") return false;
    if (search) {
      const q = search.toLowerCase();
      return cam.nameTh.includes(search) || cam.name.toLowerCase().includes(q) || cam.district.includes(search);
    }
    return true;
  });

  const filterBtns: { key: Filter; label: string; count: number; color: string }[] = [
    { key: "all",     label: "ทั้งหมด",    count: cameras.length, color: "text-foreground" },
    { key: "online",  label: "ออนไลน์",    count: online,         color: "text-green-400" },
    { key: "alert",   label: "แจ้งเตือน",  count: alerts,         color: "text-red-400" },
    { key: "offline", label: "ออฟไลน์",    count: offline,        color: "text-gray-400" },
  ];

  return (
    <div className="p-6 space-y-5 relative">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-foreground">กล้องวงจรปิด (CCTV)</h1>
          <p className="text-sm text-muted-foreground mt-0.5">ติดตามระดับน้ำจากกล้องตรวจการณ์ในกรุงเทพมหานคร</p>
        </div>
        <div className="flex items-center gap-2">
          {connected ? (
            <span className="flex items-center gap-1.5 text-xs text-green-400 bg-green-950/40 border border-green-800/40 px-2.5 py-1 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              LIVE
            </span>
          ) : (
            <span className="text-xs text-muted-foreground">กำลังเชื่อมต่อ…</span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "กล้องทั้งหมด",   value: cameras.length, color: "text-foreground",  bg: "bg-card" },
          { label: "ออนไลน์",        value: online,          color: "text-green-400",  bg: "bg-green-950/30 border-green-800/30" },
          { label: "แจ้งเตือนน้ำท่วม", value: alerts,        color: "text-red-400",    bg: "bg-red-950/30 border-red-800/30" },
          { label: "ออฟไลน์/ซ่อม",   value: offline,         color: "text-gray-400",   bg: "bg-card" },
        ].map(s => (
          <div key={s.label} className={`${s.bg} border border-border rounded-lg p-4`}>
            <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">{s.label}</div>
            <div className={`text-3xl font-bold font-mono ${s.color}`}>{s.value}</div>
          </div>
        ))}
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex gap-1 bg-secondary/40 rounded-lg p-1 border border-border">
          {filterBtns.map(btn => (
            <button
              key={btn.key}
              onClick={() => setFilter(btn.key)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                filter === btn.key ? "bg-card shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <span className={btn.color}>{btn.label}</span>
              <span className="font-mono text-muted-foreground">{btn.count}</span>
            </button>
          ))}
        </div>
        <input
          className="flex-1 h-9 px-3 rounded-lg bg-card border border-border text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-1 focus:ring-primary/50"
          placeholder="ค้นหากล้อง, เขต..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              <th className="text-left px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">กล้อง</th>
              <th className="text-left px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground hidden sm:table-cell">เขต</th>
              <th className="text-left px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">สถานะ</th>
              <th className="text-left px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">ระดับน้ำ</th>
              <th className="text-left px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground hidden md:table-cell">พิกัด</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {visible.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-4 py-10 text-center text-sm text-muted-foreground">ไม่พบกล้องที่ตรงกับเงื่อนไข</td>
              </tr>
            ) : visible.map(cam => (
              <tr
                key={cam.id}
                onClick={() => setSelected(prev => prev?.id === cam.id ? null : cam)}
                className={`cursor-pointer transition-colors ${
                  selected?.id === cam.id
                    ? "bg-primary/10 border-l-2 border-l-primary"
                    : "hover:bg-secondary/40"
                }`}
              >
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <CameraIcon color={markerColor(cam)} pulse={cam.isFloodAlert && cam.status === "online"} />
                    <div>
                      <div className="font-medium text-foreground text-sm leading-tight">{cam.nameTh}</div>
                      <div className="text-[11px] text-muted-foreground">{cam.name}</div>
                    </div>
                    {cam.isFloodAlert && cam.status === "online" && (
                      <span className="text-[10px] font-bold text-red-400 bg-red-950/50 border border-red-800/50 px-1.5 py-0.5 rounded animate-pulse">⚠ FLOOD</span>
                    )}
                  </div>
                </td>
                <td className="px-4 py-3 hidden sm:table-cell">
                  <span className="text-sm text-muted-foreground">{cam.district}</span>
                </td>
                <td className="px-4 py-3">
                  <StatusBadge status={cam.status} />
                </td>
                <td className="px-4 py-3">
                  <WaterBar level={cam.waterLevel} status={cam.status} />
                </td>
                <td className="px-4 py-3 hidden md:table-cell">
                  <span className="text-[11px] font-mono text-muted-foreground">
                    {cam.latitude.toFixed(3)}, {cam.longitude.toFixed(3)}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selected && (
        <div className="fixed inset-0 z-50 pointer-events-none">
          <div className="absolute inset-y-0 right-0 pointer-events-auto" style={{ width: 340 }}>
            <CameraDetailPanel camera={selected} onClose={() => setSelected(null)} />
          </div>
        </div>
      )}
    </div>
  );
}
