import { Link } from "wouter";
import { useGetDashboardSummary, useGetRecentActivity, useListAlerts } from "@workspace/api-client-react";
import { SeverityBadge } from "@/components/SeverityBadge";
import FloodMap from "@/components/FloodMap";

function StatCard({ label, value, sub, color }: { label: string; value: number | string; sub?: string; color?: string }) {
  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <div className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground mb-1">{label}</div>
      <div className={`text-3xl font-bold font-mono ${color ?? "text-foreground"}`}>{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-1">{sub}</div>}
    </div>
  );
}

export default function Dashboard() {
  const { data: summary, isLoading: summaryLoading } = useGetDashboardSummary();
  const { data: activity } = useGetRecentActivity();
  const { data: alerts } = useListAlerts({ resolved: false });

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-xl font-bold text-foreground">Flood Monitoring Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Real-time flood situational awareness — Greater Bangkok Area</p>
      </div>

      {summaryLoading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-card border border-border rounded-lg p-4 h-24 animate-pulse" />
          ))}
        </div>
      ) : summary ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard label="Active Incidents" value={summary.totalActiveIncidents} sub="currently active" color="text-red-400" />
          <StatCard label="Critical" value={summary.criticalIncidents} sub="requiring immediate action" color="text-purple-400" />
          <StatCard label="Affected Districts" value={summary.affectedDistricts} sub="areas impacted" color="text-orange-400" />
          <StatCard label="Avg Water Level" value={`${Math.round(summary.avgWaterLevel)} cm`} sub="active incidents" color="text-blue-400" />
        </div>
      ) : null}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-card border border-border rounded-lg overflow-hidden">
          <div className="px-4 py-3 border-b border-border flex items-center justify-between">
            <span className="text-sm font-semibold text-foreground">Live Incident Map</span>
            <span className="text-[10px] text-green-400 font-mono uppercase tracking-wider flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              Live
            </span>
          </div>
          <div style={{ height: "420px" }}>
            <FloodMap />
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-card border border-border rounded-lg">
            <div className="px-4 py-3 border-b border-border flex items-center justify-between">
              <span className="text-sm font-semibold text-foreground">Active Alerts</span>
              <Link href="/alerts">
                <span className="text-xs text-primary hover:underline cursor-pointer">View all</span>
              </Link>
            </div>
            <div className="divide-y divide-border max-h-64 overflow-y-auto">
              {!alerts || alerts.length === 0 ? (
                <div className="px-4 py-6 text-center text-sm text-muted-foreground">No active alerts</div>
              ) : alerts.slice(0, 5).map((alert: any) => (
                <div key={alert.id} className="px-4 py-3">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <span className="text-xs font-semibold text-foreground leading-tight">{alert.title}</span>
                    <SeverityBadge severity={alert.severity} />
                  </div>
                  <div className="text-[11px] text-muted-foreground line-clamp-2">{alert.message}</div>
                  <div className="text-[10px] text-muted-foreground mt-1">{alert.district}</div>
                </div>
              ))}
            </div>
          </div>

          {summary && (
            <div className="bg-card border border-border rounded-lg p-4">
              <div className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3">Severity Breakdown</div>
              {(["critical", "high", "medium", "low"] as const).map((sev) => {
                const count = summary.incidentsBySeverity[sev];
                const total = Object.values(summary.incidentsBySeverity).reduce((a, b) => a + b, 0);
                const pct = total > 0 ? Math.round((count / total) * 100) : 0;
                const barColor: Record<string, string> = { critical: "bg-purple-500", high: "bg-red-500", medium: "bg-orange-500", low: "bg-yellow-500" };
                return (
                  <div key={sev} className="mb-2">
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-muted-foreground capitalize">{sev}</span>
                      <span className="font-mono text-foreground">{count}</span>
                    </div>
                    <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                      <div className={`h-full rounded-full ${barColor[sev]}`} style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div className="bg-card border border-border rounded-lg">
        <div className="px-4 py-3 border-b border-border flex items-center justify-between">
          <span className="text-sm font-semibold text-foreground">Recent Activity</span>
          <Link href="/incidents">
            <span className="text-xs text-primary hover:underline cursor-pointer">View incidents</span>
          </Link>
        </div>
        <div className="divide-y divide-border">
          {!activity || activity.length === 0 ? (
            <div className="px-4 py-6 text-center text-sm text-muted-foreground">No recent activity</div>
          ) : activity.map((item: any) => (
            <div key={item.id} className="px-4 py-3 flex items-start gap-3">
              <div className={`w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 ${
                item.type === "resolved" ? "bg-green-400" : item.type === "alert" ? "bg-orange-400 animate-pulse" : "bg-red-400 animate-pulse"
              }`} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-semibold text-foreground">{item.title}</span>
                  <SeverityBadge severity={item.severity} />
                </div>
                <div className="text-[11px] text-muted-foreground mt-0.5">{item.description}</div>
              </div>
              <div className="text-[10px] text-muted-foreground font-mono whitespace-nowrap">
                {new Date(item.timestamp).toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
