import { useState } from "react";
import { Link } from "wouter";
import { useListFloodIncidents } from "@workspace/api-client-react";
import { SeverityBadge, StatusBadge } from "@/components/SeverityBadge";

const SEVERITIES = ["", "low", "medium", "high", "critical"];
const STATUSES = ["", "active", "monitoring", "resolved"];

export default function Incidents() {
  const [severity, setSeverity] = useState("");
  const [status, setStatus] = useState("");
  const [search, setSearch] = useState("");

  const { data: incidents, isLoading } = useListFloodIncidents({
    ...(severity ? { severity: severity as any } : {}),
    ...(status ? { status: status as any } : {}),
  });

  const filtered = incidents?.filter((i) =>
    !search || i.title.toLowerCase().includes(search.toLowerCase()) || i.district.toLowerCase().includes(search.toLowerCase())
  ) ?? [];

  return (
    <div className="p-6">
      <div className="mb-6 flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-xl font-bold text-foreground">Flood Incidents</h1>
          <p className="text-sm text-muted-foreground mt-0.5">All reported flood events across Bangkok</p>
        </div>
        <Link href="/report">
          <a className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded text-sm font-semibold hover:opacity-90 transition-opacity">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
              <path d="M12 4v16m8-8H4" />
            </svg>
            Report Incident
          </a>
        </Link>
      </div>

      <div className="flex gap-3 mb-4 flex-wrap">
        <input
          type="search"
          placeholder="Search incidents or district..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="bg-card border border-border rounded px-3 py-1.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary w-64"
        />
        <select
          value={severity}
          onChange={(e) => setSeverity(e.target.value)}
          className="bg-card border border-border rounded px-3 py-1.5 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
        >
          <option value="">All Severity</option>
          {SEVERITIES.filter(Boolean).map((s) => (
            <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
          ))}
        </select>
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="bg-card border border-border rounded px-3 py-1.5 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
        >
          <option value="">All Status</option>
          {STATUSES.filter(Boolean).map((s) => (
            <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
          ))}
        </select>
        {(severity || status || search) && (
          <button
            onClick={() => { setSeverity(""); setStatus(""); setSearch(""); }}
            className="px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground border border-border rounded transition-colors"
          >
            Clear
          </button>
        )}
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Incident</th>
              <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">District</th>
              <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Water Level</th>
              <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Severity</th>
              <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Status</th>
              <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Reported</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {isLoading ? (
              [...Array(5)].map((_, i) => (
                <tr key={i}>
                  {[...Array(7)].map((_, j) => (
                    <td key={j} className="px-4 py-3"><div className="h-4 bg-secondary rounded animate-pulse" /></td>
                  ))}
                </tr>
              ))
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-4 py-12 text-center text-muted-foreground">No incidents found</td>
              </tr>
            ) : filtered.map((incident) => (
              <tr key={incident.id} className="hover:bg-secondary/40 transition-colors">
                <td className="px-4 py-3">
                  <div className="font-semibold text-foreground text-sm">{incident.title}</div>
                  {incident.description && (
                    <div className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{incident.description}</div>
                  )}
                </td>
                <td className="px-4 py-3 text-sm text-foreground">{incident.district}</td>
                <td className="px-4 py-3 font-mono text-sm text-blue-400">{incident.waterLevel} cm</td>
                <td className="px-4 py-3"><SeverityBadge severity={incident.severity} /></td>
                <td className="px-4 py-3"><StatusBadge status={incident.status} /></td>
                <td className="px-4 py-3 text-xs text-muted-foreground font-mono">
                  {new Date(incident.reportedAt).toLocaleDateString("th-TH", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}
                </td>
                <td className="px-4 py-3">
                  <Link href={`/incidents/${incident.id}`}>
                    <a className="text-xs text-primary hover:underline">Details</a>
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length > 0 && (
          <div className="px-4 py-2 border-t border-border text-xs text-muted-foreground">
            {filtered.length} incident{filtered.length !== 1 ? "s" : ""}
          </div>
        )}
      </div>
    </div>
  );
}
