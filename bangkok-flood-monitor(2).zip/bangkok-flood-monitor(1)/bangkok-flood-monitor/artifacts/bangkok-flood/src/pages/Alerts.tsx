import { useState } from "react";
import { useListAlerts, useResolveAlert, getListAlertsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { SeverityBadge } from "@/components/SeverityBadge";

export default function Alerts() {
  const [showResolved, setShowResolved] = useState(false);
  const queryClient = useQueryClient();

  const { data: alerts, isLoading } = useListAlerts(
    showResolved ? {} : { resolved: false }
  );
  const resolveMutation = useResolveAlert();

  const handleResolve = (id: number) => {
    resolveMutation.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAlertsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListAlertsQueryKey({ resolved: false }) });
      },
    });
  };

  const active = alerts?.filter((a) => !a.isResolved) ?? [];
  const resolved = alerts?.filter((a) => a.isResolved) ?? [];

  return (
    <div className="p-6">
      <div className="mb-6 flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-xl font-bold text-foreground">Alert Management</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Monitor and resolve flood alerts for Bangkok</p>
        </div>
        <button
          onClick={() => setShowResolved(!showResolved)}
          className="px-4 py-2 bg-card border border-border rounded text-sm text-foreground hover:bg-secondary transition-colors"
        >
          {showResolved ? "Hide Resolved" : "Show Resolved"}
        </button>
      </div>

      {active.length > 0 && (
        <div className="mb-2">
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground mb-3">
            Active Alerts ({active.length})
          </div>
          <div className="space-y-3">
            {active.map((alert) => (
              <div key={alert.id} className="bg-card border border-border rounded-lg p-4 hover:border-border/80 transition-colors">
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className="font-semibold text-foreground text-sm">{alert.title}</span>
                      <SeverityBadge severity={alert.severity} />
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{alert.message}</p>
                    <div className="flex items-center gap-4 text-[11px] text-muted-foreground">
                      <span>{alert.district}</span>
                      <span className="font-mono">{new Date(alert.createdAt).toLocaleString("th-TH")}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleResolve(alert.id)}
                    disabled={resolveMutation.isPending}
                    className="px-3 py-1.5 bg-green-900/40 text-green-400 border border-green-700/50 rounded text-xs font-semibold uppercase tracking-wider hover:bg-green-900/60 transition-colors disabled:opacity-50 whitespace-nowrap"
                  >
                    Resolve
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {isLoading && (
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-28 bg-card border border-border rounded-lg animate-pulse" />
          ))}
        </div>
      )}

      {!isLoading && active.length === 0 && (
        <div className="bg-card border border-border rounded-lg p-12 text-center">
          <div className="text-green-400 text-sm font-semibold mb-1">No Active Alerts</div>
          <div className="text-xs text-muted-foreground">All alerts have been resolved</div>
        </div>
      )}

      {showResolved && resolved.length > 0 && (
        <div className="mt-6">
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground mb-3">
            Resolved ({resolved.length})
          </div>
          <div className="space-y-2">
            {resolved.map((alert) => (
              <div key={alert.id} className="bg-card/50 border border-border/50 rounded-lg p-4 opacity-60">
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className="font-semibold text-muted-foreground text-sm line-through">{alert.title}</span>
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold uppercase tracking-wider border bg-green-900/20 text-green-600 border-green-900/40">Resolved</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{alert.district}</p>
                  </div>
                  <span className="text-[10px] font-mono text-muted-foreground">
                    {alert.resolvedAt ? new Date(alert.resolvedAt).toLocaleString("th-TH") : "—"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
