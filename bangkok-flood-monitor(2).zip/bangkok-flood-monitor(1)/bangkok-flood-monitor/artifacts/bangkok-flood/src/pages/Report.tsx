import { useState } from "react";
import { useCreateFloodIncident, useCreateAlert, getListFloodIncidentsQueryKey, getListAlertsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";

const DISTRICTS = [
  "ลาดกระบัง", "บางกอกน้อย", "ดอนเมือง", "ลาดพร้าว", "มีนบุรี",
  "บึงกุ่ม", "สาทร", "พระนคร", "บางรัก", "ดุสิต",
  "บางเขน", "จตุจักร", "บางกอกใหญ่", "หนองจอก", "บางเขน",
  "ปทุมวัน", "ป้อมปราบศัตรูพ่าย", "พระโขนง", "มีนบุรี", "ราษฎร์บูรณะ",
  "สวนหลวง", "คลองสาน", "ตลิ่งชัน", "บางกรวย", "ทวีวัฒนา",
  "ธนบุรี", "บางบอน", "บางพลัด", "บึงกุ่ม", "เขตอื่นๆ",
];

export default function Report() {
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const createIncident = useCreateFloodIncident();
  const createAlert = useCreateAlert();

  const [form, setForm] = useState({
    title: "",
    description: "",
    latitude: "",
    longitude: "",
    severity: "medium" as "low" | "medium" | "high" | "critical",
    waterLevel: "",
    district: "ลาดกระบัง",
    sendAlert: true,
  });

  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!form.title || !form.latitude || !form.longitude || !form.waterLevel) {
      setError("Please fill in all required fields.");
      return;
    }

    try {
      const incident = await createIncident.mutateAsync({
        data: {
          title: form.title,
          description: form.description || undefined,
          latitude: parseFloat(form.latitude),
          longitude: parseFloat(form.longitude),
          severity: form.severity,
          waterLevel: parseFloat(form.waterLevel),
          district: form.district,
        },
      });

      if (form.sendAlert) {
        const alertSeverityMap: Record<string, "info" | "warning" | "danger" | "critical"> = {
          low: "info",
          medium: "warning",
          high: "danger",
          critical: "critical",
        };
        await createAlert.mutateAsync({
          data: {
            title: `แจ้งเตือน: ${form.title}`,
            message: form.description || `น้ำท่วมระดับ ${form.severity} ในพื้นที่ ${form.district} ระดับน้ำสูง ${form.waterLevel} ซม.`,
            severity: alertSeverityMap[form.severity],
            district: form.district,
            incidentId: incident.id,
          },
        });
      }

      queryClient.invalidateQueries({ queryKey: getListFloodIncidentsQueryKey() });
      queryClient.invalidateQueries({ queryKey: getListAlertsQueryKey() });
      setSuccess(true);

      setTimeout(() => setLocation("/incidents"), 2000);
    } catch (err) {
      setError("Failed to submit incident. Please try again.");
    }
  };

  const inputClass = "w-full bg-card border border-border rounded px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary";
  const labelClass = "block text-[11px] uppercase tracking-widest text-muted-foreground mb-1.5";

  if (success) {
    return (
      <div className="p-6 flex items-center justify-center min-h-64">
        <div className="text-center">
          <div className="w-12 h-12 bg-green-900/40 rounded-full flex items-center justify-center mx-auto mb-4 border border-green-700/50">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 text-green-400">
              <path d="M20 6L9 17l-5-5" />
            </svg>
          </div>
          <div className="text-lg font-bold text-foreground mb-1">Incident Reported</div>
          <div className="text-sm text-muted-foreground">Redirecting to incidents list...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-2xl">
      <div className="mb-6">
        <h1 className="text-xl font-bold text-foreground">Report Flood Incident</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Submit a new flood incident for monitoring</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className={labelClass}>Title *</label>
          <input
            type="text"
            required
            placeholder="e.g. น้ำท่วมถนนสายหลัก กม.5"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className={inputClass}
          />
        </div>

        <div>
          <label className={labelClass}>Description</label>
          <textarea
            rows={3}
            placeholder="ระบุรายละเอียดเพิ่มเติม..."
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className={inputClass + " resize-none"}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className={labelClass}>Latitude *</label>
            <input
              type="number"
              step="any"
              required
              placeholder="13.7563"
              value={form.latitude}
              onChange={(e) => setForm({ ...form, latitude: e.target.value })}
              className={inputClass}
            />
          </div>
          <div>
            <label className={labelClass}>Longitude *</label>
            <input
              type="number"
              step="any"
              required
              placeholder="100.5018"
              value={form.longitude}
              onChange={(e) => setForm({ ...form, longitude: e.target.value })}
              className={inputClass}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className={labelClass}>District *</label>
            <select
              value={form.district}
              onChange={(e) => setForm({ ...form, district: e.target.value })}
              className={inputClass}
            >
              {DISTRICTS.map((d) => <option key={d} value={d}>{d}</option>)}
            </select>
          </div>
          <div>
            <label className={labelClass}>Water Level (cm) *</label>
            <input
              type="number"
              step="any"
              min="0"
              required
              placeholder="30"
              value={form.waterLevel}
              onChange={(e) => setForm({ ...form, waterLevel: e.target.value })}
              className={inputClass}
            />
          </div>
        </div>

        <div>
          <label className={labelClass}>Severity *</label>
          <div className="grid grid-cols-4 gap-2">
            {(["low", "medium", "high", "critical"] as const).map((s) => {
              const colors: Record<string, string> = {
                low: "border-yellow-700/50 bg-yellow-900/20 text-yellow-400",
                medium: "border-orange-700/50 bg-orange-900/20 text-orange-400",
                high: "border-red-700/50 bg-red-900/20 text-red-400",
                critical: "border-purple-700/50 bg-purple-900/20 text-purple-400",
              };
              return (
                <button
                  key={s}
                  type="button"
                  onClick={() => setForm({ ...form, severity: s })}
                  className={`py-2 rounded border text-xs font-semibold uppercase tracking-wider transition-all ${
                    form.severity === s ? colors[s] : "border-border text-muted-foreground hover:border-border/80"
                  }`}
                >
                  {s}
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex items-center gap-3">
          <input
            type="checkbox"
            id="sendAlert"
            checked={form.sendAlert}
            onChange={(e) => setForm({ ...form, sendAlert: e.target.checked })}
            className="w-4 h-4 accent-primary"
          />
          <label htmlFor="sendAlert" className="text-sm text-foreground">
            Also send an alert notification for this incident
          </label>
        </div>

        {error && (
          <div className="px-4 py-3 bg-red-950/50 border border-red-800/50 rounded text-sm text-red-400">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={createIncident.isPending || createAlert.isPending}
          className="w-full py-2.5 bg-primary text-primary-foreground rounded text-sm font-semibold uppercase tracking-wider hover:opacity-90 transition-opacity disabled:opacity-50"
        >
          {createIncident.isPending ? "Submitting..." : "Submit Incident Report"}
        </button>
      </form>
    </div>
  );
}
