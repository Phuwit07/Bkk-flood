import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useEffect } from "react";
import Layout from "@/components/Layout";
import Dashboard from "@/pages/Dashboard";
import Incidents from "@/pages/Incidents";
import IncidentDetail from "@/pages/IncidentDetail";
import Zones from "@/pages/Zones";
import Alerts from "@/pages/Alerts";
import Report from "@/pages/Report";
import Cameras from "@/pages/Cameras";
import NotFound from "@/pages/not-found";
import { useRealtimeFeed } from "@/hooks/useRealtimeFeed";
import { useFloodAlertToast } from "@/hooks/useFloodAlertToast";

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 30000, retry: 1 } },
});

function FloodAlertWatcher() {
  const { data } = useRealtimeFeed();
  useFloodAlertToast(data?.cameras ?? []);
  return null;
}

function Router() {
  return (
    <Layout>
      <FloodAlertWatcher />
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/incidents/:id" component={IncidentDetail} />
        <Route path="/incidents" component={Incidents} />
        <Route path="/zones" component={Zones} />
        <Route path="/alerts" component={Alerts} />
        <Route path="/report" component={Report} />
        <Route path="/cameras" component={Cameras} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
