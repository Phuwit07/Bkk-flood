import { useEffect, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import type { LiveCamera } from "@/hooks/useRealtimeFeed";

export function useFloodAlertToast(cameras: LiveCamera[]) {
  const { toast } = useToast();
  const alertedIds = useRef<Set<number>>(new Set());
  const initialized = useRef(false);

  useEffect(() => {
    if (!cameras.length) return;

    if (!initialized.current) {
      cameras.forEach((c) => {
        if (c.isFloodAlert && c.status === "online") alertedIds.current.add(c.id);
      });
      initialized.current = true;
      return;
    }

    cameras.forEach((cam) => {
      if (cam.isFloodAlert && cam.status === "online" && !alertedIds.current.has(cam.id)) {
        alertedIds.current.add(cam.id);
        toast({
          title: `⚠ แจ้งเตือนน้ำท่วม — ${cam.nameTh}`,
          description: `ระดับน้ำ ${Math.round(cam.waterLevel)} cm · เขต${cam.district} · เกินเกณฑ์วิกฤต (60 cm)`,
          variant: "destructive",
          duration: 8000,
        });
      }
      if (!cam.isFloodAlert) {
        alertedIds.current.delete(cam.id);
      }
    });
  }, [cameras, toast]);
}
