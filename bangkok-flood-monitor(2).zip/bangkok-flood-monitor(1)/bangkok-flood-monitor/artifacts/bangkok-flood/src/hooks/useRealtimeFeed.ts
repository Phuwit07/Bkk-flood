import { useEffect, useRef, useState } from "react";

export type LiveCamera = {
  id: number;
  name: string;
  nameTh: string;
  district: string;
  latitude: number;
  longitude: number;
  status: "online" | "offline" | "maintenance";
  waterLevel: number;
  isFloodAlert: boolean;
  lastUpdated?: string;
};

export type LiveUpdate = {
  cameras: LiveCamera[];
  activeIncidentCount: number;
  timestamp: string;
};

export function useRealtimeFeed() {
  const [data, setData] = useState<LiveUpdate | null>(null);
  const [connected, setConnected] = useState(false);
  const esRef = useRef<EventSource | null>(null);

  useEffect(() => {
    const es = new EventSource("/api/live");
    esRef.current = es;

    es.addEventListener("connected", () => setConnected(true));
    es.addEventListener("update", (e) => {
      try {
        setData(JSON.parse(e.data));
        setConnected(true);
      } catch {}
    });
    es.onerror = () => setConnected(false);

    return () => {
      es.close();
      esRef.current = null;
    };
  }, []);

  return { data, connected };
}
