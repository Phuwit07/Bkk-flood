import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useGetDashboardSummary } from "@workspace/api-client-react";
import { useRealtimeFeed } from "@/hooks/useRealtimeFeed";

const navItems = [
  { href: "/",         label: "Dashboard",    icon: "M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" },
  { href: "/incidents",label: "Incidents",    icon: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" },
  { href: "/zones",    label: "Zones",        icon: "M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" },
  { href: "/alerts",   label: "Alerts",       icon: "M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" },
  { href: "/cameras",  label: "กล้อง CCTV",  icon: "M9,3L7.17,5H4A2,2 0 0,0 2,7V19A2,2 0 0,0 4,21H20A2,2 0 0,0 22,19V7A2,2 0 0,0 20,5H16.83L15,3M12,8A5,5 0 0,1 17,13A5,5 0 0,1 12,18A5,5 0 0,1 7,13A5,5 0 0,1 12,8M12,10A3,3 0 0,0 9,13A3,3 0 0,0 12,16A3,3 0 0,0 15,13A3,3 0 0,0 12,10Z" },
  { href: "/report",   label: "Report",       icon: "M12 4v16m8-8H4" },
];

export default function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { data: summary } = useGetDashboardSummary();
  const { data: liveData, connected } = useRealtimeFeed();

  const floodAlertCount = liveData?.cameras.filter(c => c.isFloodAlert && c.status === "online").length ?? 0;

  return (
    <div className="min-h-screen bg-background flex">
      <aside className="w-56 flex-shrink-0 border-r border-border flex flex-col">
        <div className="px-4 py-4 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="w-3.5 h-3.5 text-white">
                <circle cx="12" cy="12" r="10"/>
                <path d="M2 12h20M12 2c-3 4-3 8 0 12M12 2c3 4 3 8 0 12"/>
              </svg>
            </div>
            <div>
              <div className="text-xs font-bold text-foreground tracking-widest uppercase">BKK Flood</div>
              <div className="text-[10px] text-muted-foreground">Monitor System</div>
            </div>
          </div>
        </div>

        {summary && (summary.criticalIncidents > 0 || summary.unresolvedAlerts > 0) && (
          <div className="mx-3 mt-3 px-3 py-2 bg-red-950/60 border border-red-800/50 rounded text-xs">
            <div className="text-red-400 font-semibold uppercase tracking-wider text-[10px] mb-1">Active Alerts</div>
            {summary.criticalIncidents > 0 && (
              <div className="text-red-300">{summary.criticalIncidents} critical incident{summary.criticalIncidents !== 1 ? "s" : ""}</div>
            )}
            {summary.unresolvedAlerts > 0 && (
              <div className="text-red-300">{summary.unresolvedAlerts} unresolved alert{summary.unresolvedAlerts !== 1 ? "s" : ""}</div>
            )}
          </div>
        )}

        <nav className="flex-1 px-2 py-4 space-y-0.5">
          {navItems.map((item) => {
            const isActive = item.href === "/" ? location === "/" : location.startsWith(item.href);
            return (
              <Link key={item.href} href={item.href}>
                <span className={cn(
                  "flex items-center gap-3 px-3 py-2 rounded text-sm transition-colors cursor-pointer",
                  isActive
                    ? "bg-primary/10 text-primary border border-primary/20"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                )}>
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4 flex-shrink-0">
                    <path d={item.icon} />
                  </svg>
                  {item.label}
                  {item.href === "/alerts" && summary && summary.unresolvedAlerts > 0 && (
                    <span className="ml-auto bg-red-600 text-white text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                      {summary.unresolvedAlerts}
                    </span>
                  )}
                  {item.href === "/incidents" && summary && summary.totalActiveIncidents > 0 && (
                    <span className="ml-auto bg-orange-600 text-white text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                      {summary.totalActiveIncidents}
                    </span>
                  )}
                  {item.href === "/cameras" && floodAlertCount > 0 && (
                    <span className="ml-auto bg-red-600 text-white text-[10px] px-1.5 py-0.5 rounded-full font-bold animate-pulse">
                      {floodAlertCount}
                    </span>
                  )}
                </span>
              </Link>
            );
          })}
        </nav>

        <div className="px-4 py-3 border-t border-border">
          <div className="text-[10px] text-muted-foreground">
            <div className="flex items-center justify-between">
              <span>Bangkok Flood Monitor</span>
              {connected && <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />}
            </div>
            <div className="font-mono text-[9px] mt-0.5 text-green-500">SYSTEM ONLINE</div>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  );
}
