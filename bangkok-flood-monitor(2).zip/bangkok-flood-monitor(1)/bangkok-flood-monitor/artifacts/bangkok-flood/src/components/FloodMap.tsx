import { useState } from "react";
import { MapContainer, TileLayer, CircleMarker, Popup, Marker } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { useListFloodIncidents } from "@workspace/api-client-react";
import { useRealtimeFeed, type LiveCamera } from "@/hooks/useRealtimeFeed";
import CameraDetailPanel from "./CameraDetailPanel";

const severityColor: Record<string, string> = {
  low: "#eab308",
  medium: "#f97316",
  high: "#ef4444",
  critical: "#7c3aed",
};

const severityRadius: Record<string, number> = {
  low: 8,
  medium: 11,
  high: 14,
  critical: 17,
};

function cameraMarkerColor(cam: LiveCamera): string {
  if (cam.status === "offline") return "#6b7280";
  if (cam.status === "maintenance") return "#a855f7";
  if (cam.waterLevel >= 60) return "#ef4444";
  if (cam.waterLevel >= 35) return "#f97316";
  return "#22c55e";
}

function createCameraIcon(cam: LiveCamera, selected: boolean) {
  const color = cameraMarkerColor(cam);
  const isAlert = cam.isFloodAlert && cam.status === "online";
  const glowPx = selected ? 14 : isAlert ? 8 : 4;
  const ring = selected
    ? `<span style="position:absolute;inset:-5px;border-radius:50%;border:2px solid ${color};opacity:0.8;animation:none"></span>`
    : isAlert
    ? `<span style="position:absolute;inset:-4px;border-radius:50%;background:${color};opacity:0.25;animation:camPulse 1.5s infinite"></span>`
    : "";

  return L.divIcon({
    html: `<div style="position:relative;width:26px;height:26px">
      ${ring}
      <div style="
        width:26px;height:26px;background:${color};border-radius:50%;
        border:${selected ? "3px" : "2.5px"} solid ${selected ? "white" : "rgba(255,255,255,0.85)"};
        display:flex;align-items:center;justify-content:center;
        box-shadow:0 0 ${glowPx}px ${color};
        position:relative;z-index:1;
      ">
        <svg viewBox="0 0 24 24" fill="white" width="13" height="13">
          <path d="M9,3L7.17,5H4A2,2 0 0,0 2,7V19A2,2 0 0,0 4,21H20A2,2 0 0,0 22,19V7A2,2 0 0,0 20,5H16.83L15,3M12,8A5,5 0 0,1 17,13A5,5 0 0,1 12,18A5,5 0 0,1 7,13A5,5 0 0,1 12,8M12,10A3,3 0 0,0 9,13A3,3 0 0,0 12,16A3,3 0 0,0 15,13A3,3 0 0,0 12,10Z"/>
        </svg>
      </div>
    </div>`,
    className: "",
    iconSize: [26, 26],
    iconAnchor: [13, 13],
    popupAnchor: [0, -15],
  });
}

export default function FloodMap() {
  const { data: incidents } = useListFloodIncidents();
  const { data: liveData, connected } = useRealtimeFeed();
  const [selectedCamera, setSelectedCamera] = useState<LiveCamera | null>(null);

  const cameras = liveData?.cameras ?? [];

  return (
    <div style={{ position: "relative", width: "100%", height: "100%" }}>
      <style>{`
        @keyframes camPulse {
          0%, 100% { transform: scale(1); opacity: 0.25; }
          50% { transform: scale(1.6); opacity: 0; }
        }
      `}</style>

      {connected && (
        <div style={{
          position: "absolute", top: 8, right: selectedCamera ? 328 : 8, zIndex: 1000,
          background: "rgba(0,0,0,0.75)", borderRadius: 6, padding: "4px 8px",
          display: "flex", alignItems: "center", gap: 5, fontSize: 11, color: "#22c55e",
          backdropFilter: "blur(4px)", border: "1px solid rgba(34,197,94,0.3)",
          transition: "right 0.22s ease-out",
        }}>
          <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#22c55e", display: "inline-block", animation: "camPulse 1.5s infinite" }} />
          LIVE · {cameras.filter(c => c.status === "online").length} กล้องออนไลน์
        </div>
      )}

      <MapContainer
        center={[13.75, 100.52]}
        zoom={11}
        style={{ width: "100%", height: "100%", background: "#1a1a2e" }}
        className="rounded-b-lg"
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>'
          maxZoom={18}
        />

        {incidents?.map((incident) => {
          const color = severityColor[incident.severity] ?? "#60a5fa";
          return (
            <CircleMarker
              key={incident.id}
              center={[incident.latitude, incident.longitude]}
              radius={severityRadius[incident.severity] ?? 10}
              pathOptions={{ fillColor: color, color, weight: 2, opacity: 0.9, fillOpacity: 0.45 }}
            >
              <Popup>
                <div style={{ fontFamily: "Inter, sans-serif", minWidth: 180 }}>
                  <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 4 }}>{incident.title}</div>
                  <div style={{ fontSize: 11, color: "#9ca3af", marginBottom: 6 }}>{incident.district}</div>
                  <div style={{ fontSize: 12, marginBottom: 2 }}>
                    <span style={{ color: "#9ca3af" }}>ระดับน้ำ: </span>
                    <strong>{incident.waterLevel} cm</strong>
                  </div>
                  <div style={{ fontSize: 12 }}>
                    <span style={{ color: "#9ca3af" }}>ความรุนแรง: </span>
                    <strong style={{ color, textTransform: "uppercase" }}>{incident.severity}</strong>
                  </div>
                </div>
              </Popup>
            </CircleMarker>
          );
        })}

        {cameras.map((cam) => (
          <Marker
            key={cam.id}
            position={[cam.latitude, cam.longitude]}
            icon={createCameraIcon(cam, selectedCamera?.id === cam.id)}
            eventHandlers={{
              click: () => setSelectedCamera(prev => prev?.id === cam.id ? null : cam),
            }}
          />
        ))}
      </MapContainer>

      <div style={{
        position: "absolute", bottom: 28, left: 8, zIndex: 1000,
        background: "rgba(0,0,0,0.75)", borderRadius: 6, padding: "6px 10px",
        backdropFilter: "blur(4px)", border: "1px solid rgba(255,255,255,0.1)",
        fontSize: 10, color: "#9ca3af",
      }}>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <span style={{ color: "#7c3aed" }}>● Critical</span>
          <span style={{ color: "#ef4444" }}>● High</span>
          <span style={{ color: "#f97316" }}>● Medium</span>
          <span style={{ color: "#eab308" }}>● Low</span>
          <span style={{ color: "#6b7280", marginLeft: 4 }}>|</span>
          <span style={{ color: "#9ca3af" }}>📷 คลิกกล้องเพื่อดูกราฟ</span>
        </div>
      </div>

      {selectedCamera && (
        <CameraDetailPanel
          camera={selectedCamera}
          onClose={() => setSelectedCamera(null)}
        />
      )}
    </div>
  );
}
