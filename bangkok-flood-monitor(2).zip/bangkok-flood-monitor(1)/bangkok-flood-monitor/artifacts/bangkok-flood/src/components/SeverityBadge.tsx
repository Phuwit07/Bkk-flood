import { cn } from "@/lib/utils";

const severityConfig = {
  low:      { label: "Low",      class: "bg-yellow-900/40 text-yellow-400 border-yellow-700/50" },
  medium:   { label: "Medium",   class: "bg-orange-900/40 text-orange-400 border-orange-700/50" },
  high:     { label: "High",     class: "bg-red-900/40 text-red-400 border-red-700/50" },
  critical: { label: "Critical", class: "bg-purple-900/40 text-purple-400 border-purple-700/50" },
  info:     { label: "Info",     class: "bg-blue-900/40 text-blue-400 border-blue-700/50" },
  warning:  { label: "Warning",  class: "bg-yellow-900/40 text-yellow-400 border-yellow-700/50" },
  danger:   { label: "Danger",   class: "bg-red-900/40 text-red-400 border-red-700/50" },
};

const statusConfig = {
  active:     { label: "Active",     class: "bg-red-900/40 text-red-400 border-red-700/50" },
  monitoring: { label: "Monitoring", class: "bg-yellow-900/40 text-yellow-400 border-yellow-700/50" },
  resolved:   { label: "Resolved",   class: "bg-green-900/40 text-green-400 border-green-700/50" },
};

type SeverityKey = keyof typeof severityConfig;
type StatusKey = keyof typeof statusConfig;

export function SeverityBadge({ severity }: { severity: string }) {
  const config = severityConfig[severity as SeverityKey] ?? { label: severity, class: "bg-muted text-muted-foreground border-border" };
  return (
    <span className={cn("inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold uppercase tracking-wider border", config.class)}>
      {config.label}
    </span>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const config = statusConfig[status as StatusKey] ?? { label: status, class: "bg-muted text-muted-foreground border-border" };
  return (
    <span className={cn("inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold uppercase tracking-wider border", config.class)}>
      <span className={cn("w-1.5 h-1.5 rounded-full mr-1.5", {
        "bg-red-400 animate-pulse": status === "active",
        "bg-yellow-400": status === "monitoring",
        "bg-green-400": status === "resolved",
      })} />
      {config.label}
    </span>
  );
}
