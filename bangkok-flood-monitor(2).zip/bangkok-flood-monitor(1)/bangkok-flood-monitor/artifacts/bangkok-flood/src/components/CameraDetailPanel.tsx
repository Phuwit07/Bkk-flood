import { useEffect, useState } from "react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ReferenceLine, ResponsiveContainer,
} from "recharts";
import type { LiveCamera } from "@/hooks/useRealtimeFeed";

type Reading = { id: number; cameraId: number; waterLevel: number; recordedAt: string };
type ReadingsResponse = { camera: LiveCamera; readings: Reading[] };

function statusColor(cam: LiveCamera) {
  if (cam.status === "offline") return "#6b7280";
  if (cam.status === "maintenance") return "#a855f7";
  if (cam.waterLevel >= 60) return "#ef4444";
  if (cam.waterLevel >= 35) return "#f97316";
  return "#22c55e";
}

function levelLabel(wl: number) {
  if (wl >= 60) return { label: "วิกฤต", color: "#ef4444" };
  if (wl >= 35) return { label: "เฝ้าระวัง", color: "#f97316" };
  if (wl > 0) return { label: "ปกติ", color: "#22c55e" };
  return { label: "ไม่มีข้อมูล", color: "#6b7280" };
}

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  const wl = payload[0]?.value ?? 0;
  const { color } = levelLabel(wl);
  return (
    <div style={{
      background: "#1c1c2e", border: "1px solid rgba(255,255,255,0.1)",
      borderRadius: 8, padding: "8px 12px", fontSize: 12,
    }}>
      <div style={{ color: "#9ca3af", marginBottom: 2 }}>{label}</div>
      <div style={{ color, fontWeight: 700, fontSize: 15, fontFamily: "monospace" }}>
        {Math.round(wl)} cm
      </div>
    </div>
  );
}

export default function CameraDetailPanel({
  camera,
  onClose,
}: {
  camera: LiveCamera;
  onClose: () => void;
}) {
  const [readingsData, setReadingsData] = useState<ReadingsResponse | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    setReadingsData(null);
    fetch(`/api/cameras/${camera.id}/readings?hours=24`)
      .then((r) => r.json())
      .then((d) => { setReadingsData(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, [camera.id]);

  const chartData = (readingsData?.readings ?? []).map((r) => ({
    time: new Date(r.recordedAt).toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" }),
    level: Math.round(r.waterLevel * 10) / 10,
  }));

  const color = statusColor(camera);
  const { label: lvLabel, color: lvColor } = levelLabel(camera.waterLevel);

  const maxLevel = Math.max(...chartData.map((d) => d.level), 80);
  const gradientId = `grad-${camera.id}`;

  return (
    <div
      style={{
        position: "absolute", top: 0, right: 0, bottom: 0, width: 320,
        background: "rgba(10,10,20,0.97)", borderLeft: "1px solid rgba(255,255,255,0.08)",
        zIndex: 2000, display: "flex", flexDirection: "column",
        backdropFilter: "blur(16px)",
        animation: "slideInRight 0.22s ease-out",
      }}
    >
      <style>{`
        @keyframes slideInRight { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        @keyframes pulse24 { 0%,100%{opacity:1} 50%{opacity:.4} }
      `}</style>

      <div style={{
        padding: "14px 16px", borderBottom: "1px solid rgba(255,255,255,0.07)",
        display: "flex", alignItems: "flex-start", justifyContent: "space-between",
      }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 3 }}>
            <div style={{
              width: 8, height: 8, borderRadius: "50%", background: color, flexShrink: 0,
              animation: camera.status === "online" && camera.isFloodAlert ? "pulse24 1.5s infinite" : "none",
            }} />
            <span style={{ fontSize: 12, fontWeight: 700, color: "#f9fafb", lineHeight: 1.3 }}>
              {camera.nameTh}
            </span>
          </div>
          <div style={{ fontSize: 11, color: "#6b7280" }}>{camera.name} · {camera.district}</div>
        </div>
        <button
          onClick={onClose}
          style={{
            background: "none", border: "none", cursor: "pointer",
            color: "#6b7280", fontSize: 18, lineHeight: 1, padding: 2,
            flexShrink: 0, marginLeft: 8,
          }}
        >✕</button>
      </div>

      <div style={{ padding: "14px 16px", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 10, color: "#6b7280", marginBottom: 2, textTransform: "uppercase", letterSpacing: "0.08em" }}>
              ระดับน้ำปัจจุบัน
            </div>
            <div style={{ fontSize: 32, fontWeight: 800, fontFamily: "monospace", color: lvColor, lineHeight: 1 }}>
              {camera.status === "offline" ? "—" : `${Math.round(camera.waterLevel)}`}
              {camera.status !== "offline" && (
                <span style={{ fontSize: 14, fontWeight: 400, color: "#9ca3af", marginLeft: 2 }}>cm</span>
              )}
            </div>
          </div>
          <div style={{ marginLeft: "auto", textAlign: "right" }}>
            <span style={{
              display: "inline-block", padding: "3px 10px", borderRadius: 9999, fontSize: 11, fontWeight: 700,
              background: camera.status === "offline" ? "#1f2937" : camera.status === "maintenance" ? "#2e1065" : "transparent",
              border: `1.5px solid ${color}`, color,
            }}>
              {camera.status === "online" ? lvLabel : camera.status === "offline" ? "ออฟไลน์" : "ซ่อมบำรุง"}
            </span>
            {camera.isFloodAlert && camera.status === "online" && (
              <div style={{ marginTop: 4, fontSize: 10, color: "#ef4444", fontWeight: 600 }}>⚠ แจ้งเตือนน้ำท่วม</div>
            )}
          </div>
        </div>
      </div>

      <div style={{ padding: "14px 16px 8px", flex: 1, display: "flex", flexDirection: "column", minHeight: 0 }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: "#9ca3af", marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.08em" }}>
          ระดับน้ำ 24 ชั่วโมงที่ผ่านมา
        </div>

        {loading ? (
          <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{ fontSize: 12, color: "#6b7280" }}>กำลังโหลดข้อมูล…</div>
          </div>
        ) : chartData.length === 0 ? (
          <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{ fontSize: 12, color: "#6b7280" }}>ไม่มีข้อมูลประวัติ</div>
          </div>
        ) : (
          <div style={{ flex: 1, minHeight: 0 }}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={lvColor} stopOpacity={0.35} />
                    <stop offset="95%" stopColor={lvColor} stopOpacity={0.03} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis
                  dataKey="time"
                  tick={{ fill: "#6b7280", fontSize: 10 }}
                  tickLine={false}
                  axisLine={{ stroke: "rgba(255,255,255,0.08)" }}
                  interval={Math.floor(chartData.length / 4)}
                />
                <YAxis
                  tick={{ fill: "#6b7280", fontSize: 10 }}
                  tickLine={false}
                  axisLine={false}
                  domain={[0, Math.ceil(maxLevel * 1.2)]}
                  tickFormatter={(v) => `${v}`}
                />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine y={35} stroke="#f97316" strokeDasharray="4 3" strokeWidth={1}
                  label={{ value: "เฝ้าระวัง 35cm", position: "insideTopRight", fill: "#f97316", fontSize: 9 }} />
                <ReferenceLine y={60} stroke="#ef4444" strokeDasharray="4 3" strokeWidth={1}
                  label={{ value: "วิกฤต 60cm", position: "insideTopRight", fill: "#ef4444", fontSize: 9 }} />
                <Area
                  type="monotone" dataKey="level" stroke={lvColor} strokeWidth={2}
                  fill={`url(#${gradientId})`} dot={false} activeDot={{ r: 4, fill: lvColor, stroke: "#0a0a14", strokeWidth: 2 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div style={{ padding: "10px 16px", borderTop: "1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "#4b5563" }}>
          <span>📍 {camera.district}</span>
          <span style={{ fontFamily: "monospace" }}>
            {camera.latitude.toFixed(4)}, {camera.longitude.toFixed(4)}
          </span>
        </div>
      </div>
    </div>
  );
}
