import { Router } from "express";
import { db, cctvCamerasTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/", async (_req, res) => {
  const cameras = await db.select().from(cctvCamerasTable).orderBy(cctvCamerasTable.id);
  res.json(cameras);
});

router.get("/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  const [camera] = await db.select().from(cctvCamerasTable).where(eq(cctvCamerasTable.id, id));
  if (!camera) return res.status(404).json({ error: "Camera not found" });
  res.json(camera);
});

export default router;
