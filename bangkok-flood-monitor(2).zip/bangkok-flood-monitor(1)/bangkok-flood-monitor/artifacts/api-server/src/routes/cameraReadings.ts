import { Router } from "express";
import { db, cameraReadingsTable, cctvCamerasTable } from "@workspace/db";
import { eq, and, gte, asc } from "drizzle-orm";

const router = Router({ mergeParams: true });

router.get("/", async (req, res) => {
  const cameraId = Number(req.params.id);
  if (isNaN(cameraId)) return res.status(400).json({ error: "Invalid camera id" });

  const hours = Math.min(Number(req.query.hours ?? 24), 72);
  const since = new Date(Date.now() - hours * 60 * 60 * 1000);

  const readings = await db
    .select()
    .from(cameraReadingsTable)
    .where(and(eq(cameraReadingsTable.cameraId, cameraId), gte(cameraReadingsTable.recordedAt, since)))
    .orderBy(asc(cameraReadingsTable.recordedAt));

  const camera = await db
    .select()
    .from(cctvCamerasTable)
    .where(eq(cctvCamerasTable.id, cameraId))
    .then((r) => r[0]);

  if (!camera) return res.status(404).json({ error: "Camera not found" });

  res.json({ camera, readings });
});

export default router;
