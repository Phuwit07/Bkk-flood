import { Router, type IRouter } from "express";
import healthRouter from "./health";
import floodIncidentsRouter from "./floodIncidents";
import floodZonesRouter from "./floodZones";
import alertsRouter from "./alerts";
import dashboardRouter from "./dashboard";
import camerasRouter from "./cameras";
import liveRouter from "./live";
import cameraReadingsRouter from "./cameraReadings";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/flood-incidents", floodIncidentsRouter);
router.use("/flood-zones", floodZonesRouter);
router.use("/alerts", alertsRouter);
router.use("/dashboard", dashboardRouter);
router.use("/cameras", camerasRouter);
router.use("/live", liveRouter);
router.use("/cameras/:id/readings", cameraReadingsRouter);

export default router;
