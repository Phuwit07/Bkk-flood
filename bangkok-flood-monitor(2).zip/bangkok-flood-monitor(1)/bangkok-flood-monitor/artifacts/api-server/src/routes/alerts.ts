import { Router } from "express";
import { db } from "@workspace/db";
import { alertsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  ListAlertsQueryParams,
  CreateAlertBody,
  ResolveAlertParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  const rawResolved = req.query.resolved;
  const resolvedFilter =
    rawResolved === "true" ? true : rawResolved === "false" ? false : undefined;
  const alerts = await db
    .select()
    .from(alertsTable)
    .where(resolvedFilter != null ? eq(alertsTable.isResolved, resolvedFilter) : undefined)
    .orderBy(alertsTable.createdAt);
  res.json(alerts);
});

router.post("/", async (req, res) => {
  const body = CreateAlertBody.safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: "Invalid body" });
  const [alert] = await db.insert(alertsTable).values(body.data).returning();
  res.status(201).json(alert);
});

router.patch("/:id/resolve", async (req, res) => {
  const params = ResolveAlertParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) return res.status(400).json({ error: "Invalid id" });
  const [alert] = await db
    .update(alertsTable)
    .set({ isResolved: true, resolvedAt: new Date() })
    .where(eq(alertsTable.id, params.data.id))
    .returning();
  if (!alert) return res.status(404).json({ error: "Not found" });
  res.json(alert);
});

export default router;
