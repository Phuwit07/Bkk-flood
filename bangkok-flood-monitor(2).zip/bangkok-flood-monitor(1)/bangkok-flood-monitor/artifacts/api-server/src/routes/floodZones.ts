import { Router } from "express";
import { db } from "@workspace/db";
import { floodZonesTable, floodIncidentsTable } from "@workspace/db";
import { eq, count } from "drizzle-orm";
import {
  CreateFloodZoneBody,
  GetFloodZoneParams,
  UpdateFloodZoneParams,
  UpdateFloodZoneBody,
} from "@workspace/api-zod";

const router = Router();

router.get("/", async (_req, res) => {
  const zones = await db.select().from(floodZonesTable).orderBy(floodZonesTable.name);
  const zonesWithCounts = await Promise.all(
    zones.map(async (zone) => {
      const [result] = await db
        .select({ count: count() })
        .from(floodIncidentsTable)
        .where(eq(floodIncidentsTable.zoneId, zone.id));
      return { ...zone, activeIncidents: Number(result?.count ?? 0) };
    })
  );
  res.json(zonesWithCounts);
});

router.post("/", async (req, res) => {
  const body = CreateFloodZoneBody.safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: "Invalid body" });
  const [zone] = await db.insert(floodZonesTable).values(body.data).returning();
  res.status(201).json({ ...zone, activeIncidents: 0 });
});

router.get("/:id", async (req, res) => {
  const params = GetFloodZoneParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) return res.status(400).json({ error: "Invalid id" });
  const [zone] = await db
    .select()
    .from(floodZonesTable)
    .where(eq(floodZonesTable.id, params.data.id));
  if (!zone) return res.status(404).json({ error: "Not found" });
  const [result] = await db
    .select({ count: count() })
    .from(floodIncidentsTable)
    .where(eq(floodIncidentsTable.zoneId, zone.id));
  res.json({ ...zone, activeIncidents: Number(result?.count ?? 0) });
});

router.patch("/:id", async (req, res) => {
  const params = UpdateFloodZoneParams.safeParse({ id: Number(req.params.id) });
  const body = UpdateFloodZoneBody.safeParse(req.body);
  if (!params.success || !body.success) return res.status(400).json({ error: "Invalid input" });
  const [zone] = await db
    .update(floodZonesTable)
    .set({ ...body.data, updatedAt: new Date() })
    .where(eq(floodZonesTable.id, params.data.id))
    .returning();
  if (!zone) return res.status(404).json({ error: "Not found" });
  const [result] = await db
    .select({ count: count() })
    .from(floodIncidentsTable)
    .where(eq(floodIncidentsTable.zoneId, zone.id));
  res.json({ ...zone, activeIncidents: Number(result?.count ?? 0) });
});

export default router;
