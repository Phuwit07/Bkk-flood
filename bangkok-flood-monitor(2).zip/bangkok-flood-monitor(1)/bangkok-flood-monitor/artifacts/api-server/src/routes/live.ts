import { Router, type Request, type Response } from "express";
import { db, cctvCamerasTable, floodIncidentsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

const clients = new Set<Response>();

function sendToAll(event: string, data: unknown) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of clients) {
    try {
      res.write(payload);
    } catch {
      clients.delete(res);
    }
  }
}

async function broadcastUpdate() {
  const cameras = await db.select().from(cctvCamerasTable);
  const activeIncidents = await db
    .select()
    .from(floodIncidentsTable)
    .where(eq(floodIncidentsTable.status, "active"));

  const liveCameras = cameras.map((cam) => ({
    ...cam,
    waterLevel:
      cam.status === "online"
        ? Math.max(0, cam.waterLevel + (Math.random() * 6 - 3))
        : cam.waterLevel,
    isFloodAlert: cam.status === "online" && cam.waterLevel > 40,
    lastUpdated: new Date().toISOString(),
  }));

  sendToAll("update", {
    cameras: liveCameras,
    activeIncidentCount: activeIncidents.length,
    timestamp: new Date().toISOString(),
  });
}

let broadcastInterval: ReturnType<typeof setInterval> | null = null;

function ensureBroadcastRunning() {
  if (broadcastInterval) return;
  broadcastInterval = setInterval(() => {
    if (clients.size === 0) return;
    broadcastUpdate().catch(() => {});
  }, 5000);
}

router.get("/", async (req: Request, res: Response) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  clients.add(res);
  ensureBroadcastRunning();

  res.write(`event: connected\ndata: ${JSON.stringify({ message: "Live feed connected" })}\n\n`);

  try {
    const cameras = await db.select().from(cctvCamerasTable);
    const activeIncidents = await db
      .select()
      .from(floodIncidentsTable)
      .where(eq(floodIncidentsTable.status, "active"));

    res.write(
      `event: update\ndata: ${JSON.stringify({
        cameras,
        activeIncidentCount: activeIncidents.length,
        timestamp: new Date().toISOString(),
      })}\n\n`,
    );
  } catch {}

  req.on("close", () => {
    clients.delete(res);
  });
});

export default router;
