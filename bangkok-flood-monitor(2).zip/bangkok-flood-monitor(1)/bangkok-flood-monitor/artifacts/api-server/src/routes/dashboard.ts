import { Router } from "express";
import { db } from "@workspace/db";
import { floodIncidentsTable, alertsTable } from "@workspace/db";
import { eq, count, avg, countDistinct } from "drizzle-orm";

const router = Router();

router.get("/summary", async (_req, res) => {
  const [totalActive] = await db
    .select({ count: count() })
    .from(floodIncidentsTable)
    .where(eq(floodIncidentsTable.status, "active"));

  const [criticalCount] = await db
    .select({ count: count() })
    .from(floodIncidentsTable)
    .where(eq(floodIncidentsTable.severity, "critical"));

  const [affectedDistricts] = await db
    .select({ count: countDistinct(floodIncidentsTable.district) })
    .from(floodIncidentsTable)
    .where(eq(floodIncidentsTable.status, "active"));

  const [totalAlerts] = await db.select({ count: count() }).from(alertsTable);

  const [unresolvedAlerts] = await db
    .select({ count: count() })
    .from(alertsTable)
    .where(eq(alertsTable.isResolved, false));

  const [avgWaterResult] = await db
    .select({ avg: avg(floodIncidentsTable.waterLevel) })
    .from(floodIncidentsTable)
    .where(eq(floodIncidentsTable.status, "active"));

  const [lowCount] = await db.select({ count: count() }).from(floodIncidentsTable).where(eq(floodIncidentsTable.severity, "low"));
  const [medCount] = await db.select({ count: count() }).from(floodIncidentsTable).where(eq(floodIncidentsTable.severity, "medium"));
  const [highCount] = await db.select({ count: count() }).from(floodIncidentsTable).where(eq(floodIncidentsTable.severity, "high"));

  const [activeCount] = await db.select({ count: count() }).from(floodIncidentsTable).where(eq(floodIncidentsTable.status, "active"));
  const [monitoringCount] = await db.select({ count: count() }).from(floodIncidentsTable).where(eq(floodIncidentsTable.status, "monitoring"));
  const [resolvedCount] = await db.select({ count: count() }).from(floodIncidentsTable).where(eq(floodIncidentsTable.status, "resolved"));

  res.json({
    totalActiveIncidents: Number(totalActive?.count ?? 0),
    criticalIncidents: Number(criticalCount?.count ?? 0),
    affectedDistricts: Number(affectedDistricts?.count ?? 0),
    totalAlerts: Number(totalAlerts?.count ?? 0),
    unresolvedAlerts: Number(unresolvedAlerts?.count ?? 0),
    avgWaterLevel: parseFloat(avgWaterResult?.avg ?? "0"),
    incidentsBySeverity: {
      low: Number(lowCount?.count ?? 0),
      medium: Number(medCount?.count ?? 0),
      high: Number(highCount?.count ?? 0),
      critical: Number(criticalCount?.count ?? 0),
    },
    incidentsByStatus: {
      active: Number(activeCount?.count ?? 0),
      monitoring: Number(monitoringCount?.count ?? 0),
      resolved: Number(resolvedCount?.count ?? 0),
    },
  });
});

router.get("/heatmap", async (_req, res) => {
  const incidents = await db
    .select()
    .from(floodIncidentsTable)
    .where(eq(floodIncidentsTable.status, "active"));

  const severityToIntensity: Record<string, number> = {
    low: 0.25,
    medium: 0.5,
    high: 0.75,
    critical: 1.0,
  };

  const points = incidents.map((i) => ({
    latitude: i.latitude,
    longitude: i.longitude,
    intensity: severityToIntensity[i.severity] ?? 0.5,
    district: i.district,
  }));

  res.json(points);
});

router.get("/recent-activity", async (_req, res) => {
  const incidents = await db
    .select()
    .from(floodIncidentsTable)
    .orderBy(floodIncidentsTable.reportedAt)
    .limit(5);

  const alerts = await db
    .select()
    .from(alertsTable)
    .orderBy(alertsTable.createdAt)
    .limit(5);

  const activity = [
    ...incidents.map((i) => ({
      id: i.id,
      type: i.status === "resolved" ? "resolved" as const : "incident" as const,
      title: i.title,
      description: `${i.district} — น้ำสูง ${i.waterLevel} ซม.`,
      severity: i.severity,
      district: i.district,
      timestamp: i.reportedAt,
    })),
    ...alerts.map((a) => ({
      id: a.id + 10000,
      type: "alert" as const,
      title: a.title,
      description: a.message,
      severity: a.severity,
      district: a.district,
      timestamp: a.createdAt,
    })),
  ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 10);

  res.json(activity);
});

export default router;
