import { Router } from "express";
import { db } from "@workspace/db";
import { floodIncidentsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  ListFloodIncidentsQueryParams,
  CreateFloodIncidentBody,
  GetFloodIncidentParams,
  UpdateFloodIncidentParams,
  UpdateFloodIncidentBody,
  DeleteFloodIncidentParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  const query = ListFloodIncidentsQueryParams.safeParse(req.query);
  if (!query.success) {
    return res.status(400).json({ error: "Invalid query params" });
  }
  const { status, severity, zoneId } = query.data;
  const conditions = [];
  if (status) conditions.push(eq(floodIncidentsTable.status, status));
  if (severity) conditions.push(eq(floodIncidentsTable.severity, severity));
  if (zoneId != null) conditions.push(eq(floodIncidentsTable.zoneId, zoneId));
  const incidents = await db
    .select()
    .from(floodIncidentsTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(floodIncidentsTable.reportedAt);
  res.json(incidents);
});

router.post("/", async (req, res) => {
  const body = CreateFloodIncidentBody.safeParse(req.body);
  if (!body.success) {
    return res.status(400).json({ error: "Invalid body" });
  }
  const [incident] = await db
    .insert(floodIncidentsTable)
    .values({ ...body.data, status: "active" })
    .returning();
  res.status(201).json(incident);
});

router.get("/:id", async (req, res) => {
  const params = GetFloodIncidentParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) return res.status(400).json({ error: "Invalid id" });
  const [incident] = await db
    .select()
    .from(floodIncidentsTable)
    .where(eq(floodIncidentsTable.id, params.data.id));
  if (!incident) return res.status(404).json({ error: "Not found" });
  res.json(incident);
});

router.patch("/:id", async (req, res) => {
  const params = UpdateFloodIncidentParams.safeParse({ id: Number(req.params.id) });
  const body = UpdateFloodIncidentBody.safeParse(req.body);
  if (!params.success || !body.success) return res.status(400).json({ error: "Invalid input" });
  const [incident] = await db
    .update(floodIncidentsTable)
    .set({ ...body.data, updatedAt: new Date() })
    .where(eq(floodIncidentsTable.id, params.data.id))
    .returning();
  if (!incident) return res.status(404).json({ error: "Not found" });
  res.json(incident);
});

router.delete("/:id", async (req, res) => {
  const params = DeleteFloodIncidentParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) return res.status(400).json({ error: "Invalid id" });
  await db.delete(floodIncidentsTable).where(eq(floodIncidentsTable.id, params.data.id));
  res.status(204).send();
});

export default router;
